class Cliente:
    def __init__(self, nombre, edad, direccion, email):
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
        self.email = email

    def enviar_mail(self, mensaje):
        # Código para enviar un correo electrónico al cliente
        print(f"Enviando correo a {self.email}: {mensaje}")

    def realizar_compra(self, producto):
        # Código para procesar la compra del cliente
        print(f"{self.nombre} ha realizado la compra del producto {producto}")

    def __str__(self):
        return self.nombre
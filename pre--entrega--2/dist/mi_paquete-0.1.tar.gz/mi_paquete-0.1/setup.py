from setuptools import setup

setup(
    name='mi_paquete',
    version='0.1',
    packages=['mi_paquete'],
    author='Shirley Castro',
)
